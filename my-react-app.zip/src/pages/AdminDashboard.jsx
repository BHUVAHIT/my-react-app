import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Welcome to the admin panel.</p>
    </div>
  );
};

export default AdminDashboard;
